# Release Notes — Cantrip 1.0

- Stabilized effects/traits/modals/contracts/regions.
- Introduced trait‑declared effect bounds (E9120).
- Introduced async effect masks (E9201 fix‑it).
- Typed holes formalized (E9501–E9503).
- Clarified forbidden effects and wildcard restrictions (E9010).
- Machine‑readable diagnostics and effect sets finalized.
