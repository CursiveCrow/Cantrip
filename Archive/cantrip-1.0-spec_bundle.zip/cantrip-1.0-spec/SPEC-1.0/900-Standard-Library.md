# 900 — Standard Library (Informative Index)

Core types (`Option`, `Result`, `Vec`, `String`, maps), I/O, FS, net, time,
concurrency, and `std.effects` named effect sets including `Pure`, `SafeIO`,
`NetworkIO`, `FileIO`, `NoIO`, `GameTick`, `RealTime`, `WebService`, `DatabaseOps`.
See `STDLIB/effects-index.md`.
