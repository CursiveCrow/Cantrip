# Cantrip §55 Compliance Test Suite (Scaffold)

This scaffold validates machine‑readable outputs against the JSON Schema for §55 (MRO 1.0.0) and
performs additional normative checks (code/severity coupling, span ordering, effect metadata).

## Layout
```
cantrip-§55-tests/
  fixtures/
    diagnostics/
      E9001_missing_effect_declaration.json
      E9002_forbidden_effect_used.json
      E9010_redundant_forbidden_effect.json
      E3004_missing_move.json
      E3003_modal_state_error.json
      E5001_region_escape.json
      E1010_removed_requires_effects_syntax.json
      E1011_removed_returns_type_syntax.json
      E1012_removed_implements_syntax.json
      E9120_trait_effect_exceeds_bound.json
      E9201_async_missing_effects_mask.json
      E9501_unfilled_typed_hole.json
      E9502_typed_hole_runtime_trap.json
      E9503_hole_widens_effects.json
      E8201_overlapping_impls.json
      E8202_orphan_impl.json
      E9601_reflection_on_non_reflect_type.json
      E9602_reflection_unknown_member.json
      E9603_reflection_effect_mismatch.json
      E9310_const_generic_non_constant.json
      E9311_const_expr_not_evaluable.json
      E7801_structured_concurrency_detach.json
      W7800_forced_join_warning.json
      W0101_alias_collision.json
      E4001_cannot_prove_postcondition.json
  run.py
  README.md
```

## Running
1. Ensure Python 3.9+ is available.
2. Optional: `pip install jsonschema`
3. Run:
   ```bash
   python run.py ../cantrip-mro-1.0.0.schema.json fixtures/diagnostics
   ```

The runner will:
- Validate each JSON payload against the schema (if `jsonschema` is installed).
- Enforce normative invariants from §55:
  - `code` MUST match `^[EW]\d{4}$`. W‑codes MUST have `severity: "warning"`, E‑codes MUST have `severity: "error"`.
  - Each diagnostic MUST include a primary `span` with 1‑based line/column and `end` ⩾ `start` in document order.
  - If `typedHole` is present, `tags` MUST include `"typedHole"`.
  - If `effectSet.forbidden` is present and `declared` does not include a wildcard family, runner flags potential E9010 redundancy.
  - Summary counts MUST match observed severities.

Use these fixtures as templates: feed real compiler output to the runner to check conformance.
