#!/usr/bin/env python3
import sys, json, os, re, datetime

def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def try_schema_validate(schema_path, obj):
    try:
        import jsonschema
    except Exception:
        return ("skipped", "jsonschema not installed")
    try:
        with open(schema_path, "r", encoding="utf-8") as f:
            schema = json.load(f)
        jsonschema.validate(obj, schema)
        return ("ok", "")
    except Exception as e:
        return ("fail", str(e))

def check_norms(obj):
    errs = []

    # Root required keys
    for k in ["mroVersion","producer","target","timestamp","kind","payload"]:
        if k not in obj:
            errs.append(f"missing root key: {k}")

    # mroVersion
    if not re.match(r"^1\.0\.0(-[0-9A-Za-z\.-]+)?$", obj.get("mroVersion","")):
        errs.append("mroVersion must be '1.0.0' semver-compatible")

    # Timestamp parse
    try:
        datetime.datetime.fromisoformat(obj["timestamp"].replace("Z","+00:00"))
    except Exception:
        errs.append("timestamp must be ISO 8601")

    # Kind
    if obj.get("kind") != "diagnostics":
        errs.append("fixture kind must be 'diagnostics'")

    diags = obj.get("payload",{}).get("diagnostics",[])

    # Summary counts
    s = obj.get("payload",{}).get("summary",{})
    ecount = sum(1 for d in diags if d.get("severity") == "error")
    wcount = sum(1 for d in diags if d.get("severity") == "warning")
    if s.get("errorCount") != ecount or s.get("warningCount") != wcount:
        errs.append(f"summary counts mismatch (expected errors={ecount}, warnings={wcount})")

    for idx, d in enumerate(diags):
        code = d.get("code","")
        if not re.match(r"^[EW]\d{4}$", code):
            errs.append(f"diag[{idx}] code format invalid: {code}")
        sev = d.get("severity")
        if code.startswith("E") and sev != "error":
            errs.append(f"diag[{idx}] error code must have severity=error (got {sev})")
        if code.startswith("W") and sev != "warning":
            errs.append(f"diag[{idx}] warning code must have severity=warning (got {sev})")
        span = d.get("span",{})
        for p in ["start","end"]:
            if p not in span:
                errs.append(f"diag[{idx}] span missing {p}")
                continue
            pos = span[p]
            if pos.get("line",0) < 1 or pos.get("column",0) < 1:
                errs.append(f"diag[{idx}] span {p} must be 1-based")
        # typedHole tag coupling
        if "typedHole" in d:
            tags = d.get("tags",[])
            if "typedHole" not in tags:
                errs.append(f"diag[{idx}] typedHole present but tags missing 'typedHole'")

        # Redundant forbidden effect heuristic for E9010
        if code == "E9010":
            eff = d.get("effectSet",{})
            if eff and eff.get("declared"):
                has_wildcard = any(x.endswith(".*") for x in eff.get("declared",[]))
                if has_wildcard:
                    errs.append(f"diag[{idx}] E9010 with wildcard present; likely WILD restriction, not redundant")
    return errs

def main():
    if len(sys.argv) < 3:
        print("usage: run.py <schema.json> <fixtures-dir>")
        return 2
    schema_path = sys.argv[1]
    fixtures_dir = sys.argv[2]
    failures = 0

    for root, _, files in os.walk(fixtures_dir):
        for fn in sorted(files):
            if not fn.endswith(".json"): 
                continue
            path = os.path.join(root, fn)
            obj = load(path)
            status, msg = try_schema_validate(schema_path, obj)
            norms = check_norms(obj)
            ok = (status in ("ok","skipped")) and (not norms)
            print(f"[{'PASS' if ok else 'FAIL'}] {fn}  schema={status}" + (f" ({msg})" if msg else ""))
            for n in norms:
                print(f"   - {n}")
            if not ok:
                failures += 1
    if failures:
        print(f"\n{failures} file(s) failed checks.")
        sys.exit(1)
    print("\nAll fixtures passed checks.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
